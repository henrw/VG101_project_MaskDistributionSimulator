#pragma once

#include <string>
#include <vector>

typedef struct CITY
{
	std::string name;

	/*Parameters for plotting*/

	//The origin point of circle
	int center_x;
	int center_y;

	//The point where the car begins moving
	int square_x;
	int square_y;

	//the point where the city name is printed at
	int name_x;
	int name_y;

	//Radius of circle
	int R;

	/* SIR model
	 *
	/ Effective Contact Rate: eff_rt= a + b*(1-e^(-(sus_num + inf_num + rec_num)/(radius*radius*cur_msk_num)))
	/ Recovery Rate: rec_rt= 1/(15+15(1-e^(-inf_num/hspt_num)
	 * these two parameters applies the model 1-e^(-x)
	*/
	float sus_num; //Those susceptible but not yet infected with the disease
	float inf_num; //Infectious (infected) individuals
	float rec_num; //Those individuals who have recovered and have immunity
	float total_num;
	//Only display the integer part of the number!

	float is_produce;//Whether or not the city produce masks in large scale
	float prod_rt;//The increment of masks for every period of time
	float cur_msk_num;//Current mask number
	float req_msk_num;//Required mask number
	float hspt_num;//Hospital number
	float eff_rt;//Effective Contact Rate
	float rec_rt;//Recovery rate

	//�ϸ�Сʱ�Ŀ�������
	int pre_hour_mask_num;
	//���Сʱ�Ŀ�������
	int current_hour_mask_num = -1;
	//����������ʷ����
	std::vector<float> history_inf_nums;
} _CITY;
