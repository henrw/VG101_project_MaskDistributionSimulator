#pragma once

#include "global_values.h"


//��������ʱ��
void ComputeVirtualTime()
{
	time_t tnow;
	time(&tnow);
	int real = 3;
	int real_delta_time = tnow - start_time;
	real_delta_time = real_delta_time / real * real;

	//����10�����1Сʱ����ӳ�����������ǰ��ʱ��
	time_t delta_time = (real_delta_time) * (3600 / real);

	current_virtual_time = virtual_start_time + delta_time;
}

//initialize time
void InitializeTime()
{
	struct tm sttm;
	memset(&sttm, 0, sizeof(sttm));
	sttm.tm_year = 2020 - 1900;
	sttm.tm_mon = 1 - 1;
	sttm.tm_mday = 24;
	sttm.tm_hour = 12;
	sttm.tm_min = 1;
	virtual_start_time = mktime(&sttm);

	time(&start_time);

	//cpmpute virtual time
	ComputeVirtualTime();
	start_virtual_time = current_virtual_time;
}

//initialize city data
void InitializeCityDatas()
{
	_SYS sys_instance;
	for (int i = 0; i < city_count; ++i)
	{
		auto& city = city_infos[i];
		sys_instance.city[i] = &city;
	}
	initialization(&sys_instance);
}