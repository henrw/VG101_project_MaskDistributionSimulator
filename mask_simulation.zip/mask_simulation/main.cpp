
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include "GL/glut.h"
#include <math.h>
#include <string>
#include <time.h>
#include <ctime>
#include <iostream>
#include "mask_simulation.h"
#include "global_values.h"
#include "input_functions.h"
#include "draw_input_ui.h"
#include "initialize_functions.h"
#include "draw_base_functions.h"

#pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")

float PI = 3.141592653;

int half_screen_width = screen_width / 2;
int half_screen_height = screen_height / 2;

//the ratio of the height and the wide
float radio = screen_width / screen_height;


const int major_city_index = 0;

bool is_translating = false;
bool is_hour_changed = false;

//the maximum day number that the function plotting shows
int history_inf_cache_count = 220;

int current_hour = 0;
int pre_hour = -1;

//the period that the infected people be updated
int inf_refresh_cycle = 60 * 5;
int inf_pre_cycle_pos = 0;
bool need_refresh_inf = false;



//small sqaure in the city
void DrawSmallSquare(int x_offset, int y_offset)
{
	glColor3f(0.0f, 0.0f, 0.0f);
	int length = 7;
	glRectf(ParseOpenGLX(x_offset - length), ParseOpenGLY(y_offset - length), ParseOpenGLX(x_offset + length), ParseOpenGLY(y_offset + length));
}

//circle (the shape of the city)
void DrawCircle(int r, int x_offset, int y_offset, int inf_num)
{
	//the color got darker as the infected people number become larger
	glColor3f(max((225.0f - inf_num), 70) / 255.0f
		, max((235.0f - inf_num), 70) / 255.0f
		, max((247.0f - inf_num), 70) / 255.0f);
	int n = 200;
	glBegin(GL_POLYGON);
	for (int i = 0; i < n; i++)
	{
		GLfloat x = ParseOpenGLX(r *cos(2 * PI / n * i) + x_offset);
		//ellipse
		GLfloat y = ParseOpenGLY(r * yscale *sin(2 * PI / n * i) + y_offset);
		glVertex2f(x, y);
	}
	glEnd();
}

//the road
void DrawRoad(int start_index, int end_index, int min_diff_val, int max_diff_val)
{
	const auto& start_city = city_infos[start_index];
	const auto& end_city = city_infos[end_index];
	int delta_x = end_city.square_x - start_city.square_x;
	int delta_y = end_city.square_y - start_city.square_y;

	float length = sqrt(delta_x * delta_x + delta_y * delta_y);
	float normal_delta_x = delta_x / length;
	float normal_delta_y = delta_y / length;

	glColor3f(0.9f, 0.9f, 0.0f);
	glBegin(GL_POLYGON);
	int road_width = 7;
	int inner_road_width = 0.5 * road_width;
	int inner_road_bold_width = road_width - inner_road_width;
    //the outer side of the road
	//	starting point
	int start_x_1 = start_city.square_x - normal_delta_y * road_width;
	int start_y_1 = start_city.square_y + normal_delta_x * road_width;
	int start_x_2 = start_city.square_x + normal_delta_y * road_width;
	int start_y_2 = start_city.square_y - normal_delta_x * road_width;
	glVertex2f(ParseOpenGLX(start_x_1), ParseOpenGLY(start_y_1));
	glVertex2f(ParseOpenGLX(start_x_2), ParseOpenGLY(start_y_2));
	//ending point
	int end_x_1 = end_city.square_x + (-normal_delta_x * 2 + normal_delta_y) * road_width;
	int end_y_1 = end_city.square_y + (-normal_delta_y * 2 - normal_delta_x) * road_width;
	int end_x_2 = end_city.square_x + (-normal_delta_x * 2 - normal_delta_y) * road_width;
	int end_y_2 = end_city.square_y + (-normal_delta_y * 2 + normal_delta_x) * road_width;
	glVertex2f(ParseOpenGLX(end_x_1), ParseOpenGLY(end_y_1));
	glVertex2f(ParseOpenGLX(end_city.square_x), ParseOpenGLY(end_city.square_y));
	glVertex2f(ParseOpenGLX(end_x_2), ParseOpenGLY(end_y_2));
	glEnd();
	//the inner side of the road
	
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_POLYGON);
	glVertex2f(ParseOpenGLX(start_x_1 + (normal_delta_x + normal_delta_y) * inner_road_bold_width), ParseOpenGLY(start_y_1 + (-normal_delta_x + normal_delta_y) * inner_road_bold_width));
	glVertex2f(ParseOpenGLX(start_x_2 + (normal_delta_x - normal_delta_y) * inner_road_bold_width), ParseOpenGLY(start_y_2 + (normal_delta_x + normal_delta_y) * inner_road_bold_width));
	glVertex2f(ParseOpenGLX(end_x_1 + (- normal_delta_y) * inner_road_bold_width), ParseOpenGLY(end_y_1 + (normal_delta_x) * inner_road_bold_width));
	glVertex2f(ParseOpenGLX(end_city.square_x - normal_delta_x * inner_road_bold_width * 1.5), ParseOpenGLY(end_city.square_y - normal_delta_y * inner_road_bold_width * 1.5));
	glVertex2f(ParseOpenGLX(end_x_2 + (+ normal_delta_y) * inner_road_bold_width), ParseOpenGLY(end_y_2 + (-normal_delta_x) * inner_road_bold_width));
	glEnd();

	//rolling animation(car)
	glColor3f(0.3f, 0.3f, 0.3f);
	
	int tag_length = 15;
	int half_tag_length = tag_length / 2;

	// display the animation through timestamp(ms)
	int current_pos = 10;
	if (is_translating)
	{
		//translation speed
		auto diff = end_city.current_hour_mask_num - end_city.pre_hour_mask_num;
		int t = 0;
		
		if ((max_diff_val - min_diff_val) != 0)
		{
			t = (diff - min_diff_val) / (max_diff_val - min_diff_val);
		}
		//max_speed min_speed
		float max_speed = 15;
		float min_speed = 2;
		float speed = (max_speed - min_speed) * t + min_speed;
		current_pos += (int(clock() / (100.0f / speed)) % 30);
	}

	while (true)
	{
		int farest_x_delta = normal_delta_x * (current_pos + tag_length + half_tag_length);
		int farest_y_delta = normal_delta_y * (current_pos + tag_length + half_tag_length);
		int current_length = sqrt(farest_x_delta * farest_x_delta + farest_y_delta * farest_y_delta);
		
		//drawing small arrow repeatdely until reaching the ending point
		if (current_length < length - 10)
		{
			glColor3f(0.9f, 0.9f, 0.0f);
			glBegin(GL_POLYGON);
			glVertex2f(ParseOpenGLX(start_city.square_x + normal_delta_x * (current_pos + half_tag_length)), ParseOpenGLY(start_city.square_y + normal_delta_y * (current_pos + half_tag_length)));
			glVertex2f(ParseOpenGLX(start_x_1 + normal_delta_x * current_pos), ParseOpenGLY(start_y_1 + normal_delta_y * current_pos));
			glVertex2f(ParseOpenGLX(start_x_1 + normal_delta_x * (current_pos + tag_length)), ParseOpenGLY(start_y_1 + normal_delta_y * (current_pos + tag_length)));
			glVertex2f(ParseOpenGLX(start_city.square_x + farest_x_delta), ParseOpenGLY(start_city.square_y + farest_y_delta));
			glVertex2f(ParseOpenGLX(start_x_2 + normal_delta_x * (current_pos + tag_length)), ParseOpenGLY(start_y_2 + normal_delta_y * (current_pos + tag_length)));
			glVertex2f(ParseOpenGLX(start_x_2 + normal_delta_x * current_pos), ParseOpenGLY(start_y_2 + normal_delta_y * current_pos));
			glEnd();

			current_pos += 30;
		}
		else
		{
			break;
		}
	}
}



//drawing
void ShowCities()
{
	//draw cities
	for (int i = 0 ; i < city_count ; i++)
	{
		const auto& city = city_infos[i];
		DrawCircle(city.R, city.center_x, city.center_y, city.inf_num);
		DrawSmallSquare(city.square_x, city.square_y);
		DrawString(city.name, city.name_x, city.name_y, GLUT_BITMAP_TIMES_ROMAN_24);
	}

	int min_diff_val = 10000000, max_diff_val = 0;
	//computing the maximum speed and the minimum speed
	for (int i = 1; i < city_count; i++)
	{
		const auto& city = city_infos[i]; 
		auto diff = city.current_hour_mask_num - city.pre_hour_mask_num;
		if (diff < min_diff_val) min_diff_val = diff;
		if (diff > max_diff_val) max_diff_val = diff;
	}

	//draw roads
	DrawRoad(major_city_index, 1, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 2, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 3, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 4, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 5, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 6, min_diff_val, max_diff_val);
	DrawRoad(major_city_index, 7, min_diff_val, max_diff_val);
}

//show the data
void DrawCityDatas()
{
	DrawString("City", 710, 80); DrawString("Citizens", 760, 80); DrawString("infected", 840, 80); DrawString("masks", 925, 80);
	for (int i = 0; i < city_count; i++)
	{
		const auto& city = city_infos[i];
		int row = i;
		switch (row)
		{
		case 0:
			row = 1;
			break;
		case 1:
			row = 0;
		default:
			break;
		}
		int y_pos = 120 + 40 * row;
		char inf_num_str[128];
		_itoa(city.inf_num, inf_num_str, 10);
		char cur_msk_num_str[128];
		//mask number can not be smaller that 0
		auto cur_msk_num = max(city.cur_msk_num, 0);
		_itoa(cur_msk_num, cur_msk_num_str, 10);
		DrawString(city.name, 710, y_pos); DrawString("1000", 760, y_pos); DrawString(inf_num_str, 840, y_pos); DrawString(cur_msk_num_str, 925, y_pos);
	}
}

//city's dialog
void ShowDialog()
{
	if (dialog_city_index >= 0)
	{
		const auto& city_info = city_infos[dialog_city_index];

		glColor3f(0.9f, 0.9f, 0.9f);
		int x1 = 300, x2 = screen_width - 300, y1 = 50, y2 = screen_height - 50;
		glRectf(ParseOpenGLX(x1), ParseOpenGLY(y1), ParseOpenGLX(x2), ParseOpenGLY(y2));

		//title
		std::string city = "City ";
		city += city_info.name;
		DrawString(city, x1 + 180, y1 + 30);

		//axis

		glColor3f(0.0f, 0.0f, 0.0f);
		glBegin(GL_LINES);

		int x_origin = x1 + 80;
		int y_origin = y2 - 100;
		int x_end = x2 - 80;
		int y_end = y1 + 100;
		//x_axis
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_origin));
		glVertex2f(ParseOpenGLX(x_end), ParseOpenGLY(y_origin));
		glVertex2f(ParseOpenGLX(x_end), ParseOpenGLY(y_origin));
		glVertex2f(ParseOpenGLX(x_end - 10), ParseOpenGLY(y_origin - 10));
		glVertex2f(ParseOpenGLX(x_end), ParseOpenGLY(y_origin));
		glVertex2f(ParseOpenGLX(x_end - 10), ParseOpenGLY(y_origin + 10));
		//y_axis
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_origin));
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_end));
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_end));
		glVertex2f(ParseOpenGLX(x_origin + 10), ParseOpenGLY(y_end + 10));
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_end));
		glVertex2f(ParseOpenGLX(x_origin - 10), ParseOpenGLY(y_end + 10));
		glEnd();
		//function plotting
		glBegin(GL_LINE_STRIP);
		glVertex2f(ParseOpenGLX(x_origin), ParseOpenGLY(y_origin));
		for (int i = 0; i < history_inf_cache_count && i < city_info.history_inf_nums.size(); i++)
		{
			int y = y_origin - city_info.history_inf_nums[i];
			y = max(y, y_end);
			glVertex2f(ParseOpenGLX(i + x_origin), ParseOpenGLY(y));
		}
		glEnd();

		//text
		char inf_num_str[128];
		_itoa(city_info.inf_num, inf_num_str, 10);
		char rec_rt_str[128];
		snprintf(rec_rt_str, 128, "%7f", city_info.rec_rt);
		DrawString(std::string("infected people:") + inf_num_str, x_origin, y_origin + 40);
		DrawString(std::string("Recovery Rate:") + rec_rt_str, x_origin, y_origin + 70);
	}
}

//how time
void ShowDate()
{
	{
		//outline border
		glColor3f(0.0f, 0.0f, 0.0f);
		glRectf(ParseOpenGLX(383), ParseOpenGLY(427), ParseOpenGLX(683), ParseOpenGLY(483));
		glColor3f(1.0f, 1.0f, 1.0f);
		glRectf(ParseOpenGLX(383 + 2), ParseOpenGLY(427 + 2), ParseOpenGLX(683 - 2), ParseOpenGLY(483 - 2));
		glColor3f(0.0f, 0.0f, 0.0f);
		
		struct tm t;
		localtime_s(&t, &current_virtual_time);
		char data_str[128];
		sprintf_s(data_str, "%02d:%02d  %s  %d, %d", t.tm_hour, t.tm_min, "March", t.tm_mday, t.tm_year + 1900);
		
		DrawString(data_str, 426, 465, GLUT_BITMAP_TIMES_ROMAN_24);
	}
}

//the digit in the road
void DrawRoadText()
{
	DrawString2("10000", 222, 167, 20);//A
	DrawString2("20000", 400, 135, 20);//C
	DrawString2("22000", 324, 298, 70);//D
	DrawString2("20000", 396, 190, -85);//E
	DrawString2("20000", 435, 175, -40);//F
	DrawString2("30000", 195, 277, 55);//G
	DrawString2("22000", 381, 290, -90);//H
}

//refresh data
void RefreshDatas()
{
	//compute the current time
	int current_hour = (current_virtual_time - start_virtual_time) / 3600;
	is_hour_changed = current_hour != pre_hour;
	pre_hour = current_hour;

	//compute the refreshing period of function plotting
	int current_cycle_pos = (current_virtual_time - start_virtual_time) / inf_refresh_cycle;
	need_refresh_inf = current_cycle_pos != inf_pre_cycle_pos;
	inf_pre_cycle_pos = current_cycle_pos;

	
	auto sub_virtual_time = (current_virtual_time - start_virtual_time) % (12 * 3600);
	//if it it transmission time
	is_translating = sub_virtual_time < 3600;

	float delta = current_virtual_time - pre_virtual_time;
	//time interval->hours
	auto delta_t = delta / 3600.0f;

	_SYS sys_instance;
	sys_instance.city_num = city_count;
	for (int i = 0; i < city_count; ++i)
	{
		auto& city = city_infos[i];
		sys_instance.city[i] = &city;
	}

	sir_renew(&sys_instance, delta_t);
	parameter_renew(&sys_instance);
	mask_require(&sys_instance);
	mask_change(&sys_instance, is_translating ? 0 : 1, delta_t);

	for (int i = 0; i < city_count; ++i)
	{
		auto& city = city_infos[i];
		if (is_hour_changed)
		{
			city.pre_hour_mask_num = city.current_hour_mask_num;
			
			if (city.pre_hour_mask_num == -1)
			{
				city.pre_hour_mask_num = city.cur_msk_num;
			}
			city.current_hour_mask_num = city.cur_msk_num;
		}

		if (need_refresh_inf)
		{
			
			city.history_inf_nums.push_back(city.inf_num);
			
			if (city.history_inf_nums.size() >= history_inf_cache_count)
			{
				city.history_inf_nums.erase(city.history_inf_nums.begin());
			}
		}
	}
}

//MAIN FUNCTION OF DRAWING
void Show()
{
	glClear(GL_COLOR_BUFFER_BIT); 
	glDisable(GL_DEPTH_TEST);
	
	glColor3f(100.0f / 255.0f, 129.0f / 255.0f, 192.0f / 255.0f);
	glRectf(ParseOpenGLX(0), ParseOpenGLY(0), ParseOpenGLX(screen_width), ParseOpenGLY(screen_height));
	
	glColor3f(1.0f, 1.0f, 1.0f);
	glRectf(ParseOpenGLX(10), ParseOpenGLY(25), ParseOpenGLX(690), ParseOpenGLY(490));

	
	glColor3f(1.0f, 1.0f, 1.0f);
	glRectf(ParseOpenGLX(700), ParseOpenGLY(25), ParseOpenGLX(990), ParseOpenGLY(490));



	if (is_inputed_values)
	{
		pre_virtual_time = current_virtual_time;
		ComputeVirtualTime();
		RefreshDatas();
		ShowCities();
		DrawCityDatas();
		ShowDate();
		DrawRoadText();
		ShowDialog();
	}
	else
	{
		DrawInputUI();
	}

	glutSwapBuffers();
}

void IdleFunc()
{
	glutPostRedisplay();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_MULTISAMPLE);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(1000, 500);
	glutCreateWindow("Graph");
	glutDisplayFunc(Show);
	glutMouseFunc(MouseFunc);
	glutKeyboardFunc(KeyboardFuncInputValues);
	glutIdleFunc(IdleFunc);
	glutMainLoop();
	return 0;
}