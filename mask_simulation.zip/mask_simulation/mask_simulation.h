//
// Created by wumuzhe on 2020/7/18.
//

#ifndef CLION_MASK_SIMULATION_H
#define CLION_MASK_SIMULATION_H
#include<string>
#include <vector>

#include "city.h"

// define some const here

//static float PI=3.141592653;
//
//static float all_scale=1.0f;

using namespace std;

typedef struct SYS
{
    _CITY *city[8];
    int city_num = 8;
    string time;

} _SYS;

/*function prototypes
 */

//initialize the system
void initialization(_SYS *sys1);

//Calculate the required mask number for each city
//Input: the pointer of system
//Changes: sys1->city[ALL]->req_msk_num (required mask number) updated
void mask_require(_SYS *sys1);

//Calculate eff_rt, rec_rt in SIR model
//Input: the pointer of system
//Changes: sys1->city[ALL]->eff_rt (effective contact rate) & rec_rt (recovery rate) updated
void parameter_renew(_SYS *sys1);

//Calculate sus_num, inf_num, rec_num in SIR model
//Input: the pointer of system
//Changes: sys1->city[ALL]->sus_num (number of suspected people) & inf_num (...) & rec_num (...) updated
void sir_renew(_SYS *sys1, float delta_t);

//Mask consumed, masks produced, masks transported
//Input: the pointer of system
//Changes: sys1->city[ALL]->cur_msk_num (current mask number) updated
void mask_change(_SYS *sys1, int isTransport,float delta_t);

#endif //CLION_MASK_SIMULATION_H
