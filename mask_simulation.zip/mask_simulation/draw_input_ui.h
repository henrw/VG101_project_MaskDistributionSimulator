#pragma once

#include "draw_base_functions.h"

void DrawInputUI()
{
	glColor3f(1.0f, 1.0f, 1.0f);
	glRectf(ParseOpenGLX(10), ParseOpenGLY(25), ParseOpenGLX(990), ParseOpenGLY(490));
	
	DrawString("Please enter the mask production capacity (pieces per day)", 290, 130);
	DrawString("major industrial city:", 290, 210);
	DrawString("other cities:", 290, 290);

	glColor3f(current_major_input_color, current_major_input_color, current_major_input_color);
	//main city
	glRectf(ParseOpenGLX(major_city_input_x1), ParseOpenGLY(major_city_input_y1), ParseOpenGLX(major_city_input_x2), ParseOpenGLY(major_city_input_y2));
	DrawString(major_city_string.c_str(), 480, 210);

	glColor3f(current_other_input_color, current_other_input_color, current_other_input_color);
	//other cities
	glRectf(ParseOpenGLX(other_city_input_x1), ParseOpenGLY(other_city_input_y1), ParseOpenGLX(other_city_input_x2), ParseOpenGLY(other_city_input_y2));
	DrawString(other_city_string.c_str(), 480, 290);

	glColor3f(0.5, 0.5, 0.5);
	glRectf(ParseOpenGLX(ok_button_x1), ParseOpenGLY(ok_button_y1), ParseOpenGLX(ok_button_x2), ParseOpenGLY(ok_button_y2));
	//OK bottum
	DrawString("OK", 635, 395);
}