#include "global_values.h"

float all_scale = 1.0f;

int screen_width = 1000 * all_scale;
int screen_height = 500 * all_scale;

bool is_inputed_values = false;

float yscale = 0.85f;

int dialog_city_index = -1;

_CITY city_infos[city_count] = {
	{ "B", 355, 139, 378, 158, 337, 132, 82 },
	{ "A", 178, 198, 179, 194, 138, 200, 75 },
	{ "C", 540, 126, 532, 126, 572, 139, 58 },
	{ "D", 264, 301, 271, 307, 270, 287, 70 },
	{ "E", 387, 262, 385, 253, 406, 281, 39 },
	{ "F", 531, 261, 519, 231, 557, 284, 65 },
	{ "G", 138, 384, 153, 338, 132, 401, 95 },
	{ "H", 409, 368, 354, 355, 438, 402, 90 }, };

time_t start_time;
time_t virtual_start_time;
time_t current_virtual_time;
time_t pre_virtual_time;
time_t start_virtual_time;

float current_major_input_color = normal_input_color;
float current_other_input_color = normal_input_color;

extern std::string major_city_string = "3000";
extern std::string other_city_string = "1000";

int major_city_prod_rt = 3000;
int other_city_prod_rt = 1200;